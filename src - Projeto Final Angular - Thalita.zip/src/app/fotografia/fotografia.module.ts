import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { FormularioComponent } from "./formulario/formulario.component";
import { FotoComponent } from "./foto/foto.component";
import { IntroducaoComponent } from "./introducao/introducao.component";
import { SharedModule } from "../shared/shared.module";


@NgModule({
    //Determina quais componentes são de responsabilidade do módulo
    declarations: [
        FotoComponent,
        FormularioComponent,
        IntroducaoComponent
    ],

    imports: [
        BrowserModule,
        FormsModule,  
        ReactiveFormsModule
    ],

    exports: [
        FotoComponent,
        FormularioComponent
    ],
})
export class FotografiaModule{}