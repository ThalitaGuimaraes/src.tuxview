export interface Fotos{
    id: number,
    imagem: string,
    titulo: string
}